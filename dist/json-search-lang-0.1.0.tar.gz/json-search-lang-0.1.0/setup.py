# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['json_search_lang']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'json-search-lang',
    'version': '0.1.0',
    'description': 'A way to parse json in a fancy matter!',
    'long_description': 'WORK IN PROGRESS, NO REASON TO INSTALL FOR NOW!\n\n',
    'author': 'Vivax',
    'author_email': 'vivax3794@protonmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
